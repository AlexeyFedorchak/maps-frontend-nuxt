<script setup lang="ts">
import { computed, type HTMLAttributes } from "vue"
import { useVModel } from "@vueuse/core"
import type { DateValue } from "@internationalized/date"
import { parseDate } from "@internationalized/date"
import { formatDate } from "@/utils/date"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

const props = defineProps<{
  modelValue?: Date
  defaultValue?: Date
  class?: HTMLAttributes["class"]
}>()

const emits = defineEmits<{
  (e: "update:modelValue", payload: Date | undefined): void
}>()

const modelStr = useVModel<Date | undefined>(props, "modelValue", emits, {
  passive: true,
  defaultValue: props.defaultValue,
})

const calendarValue = computed<DateValue | undefined>({
  get() {
    if (!modelStr.value) return undefined
    try { return parseDate(modelStr.value) } catch { return undefined }
  },
  set(v) {
    modelStr.value = v ? v.toString() : undefined
  }
})

const formattedDate = computed(() => formatDate(modelStr.value))
</script>

<template>
  <Popover>
    <PopoverTrigger as-child>
      <Button
          variant="outline"
          :class="cn('h-[50px] justify-start text-left font-normal pl-0 pr-[20px] rounded-xl')"
      >
        <span class="inline-block pl-[20px] pr-[20px] pt-[7px] pb-[7px] border-r border-input">Date</span>
        <span :class="cn(!modelStr && 'text-muted-foreground')">
          {{ modelStr ? formattedDate : "dd/mm/yyyy" }}
        </span>
      </Button>
    </PopoverTrigger>
    <PopoverContent class="w-auto p-0">
      <Calendar v-model="calendarValue" initial-focus />
    </PopoverContent>
  </Popover>
</template>
